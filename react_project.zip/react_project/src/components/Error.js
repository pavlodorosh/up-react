function Error() {
    return (
        <div>
            <h2>404 Error</h2>
        </div>
    );
}

export default Error;